// Copyright 2019 <Vitoga Geogege Patrick>
#include <iostream>

#include "SkipList.h"


int main() {
    int drivers, races, prints;
    solve(drivers, races, prints);

    return 0;
}
